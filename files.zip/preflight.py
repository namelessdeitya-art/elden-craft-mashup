import json,sys,glob
S={}
for f in glob.glob("sheets/*.json"):
    d=json.load(open(f)); S[d["sheet"]]=d
ids={s:{r["id"] for r in d["rows"]} for s,d in S.items()}
bad=[]
for s,d in S.items():
    for r in d["rows"]:
        for c in d["columns"]:
            if r.get(c) is None: bad.append(f"UNFILLED {s}.{r['id']}.{c}")
        if r.get("verified") is False: bad.append(f"UNVERIFIED {s}.{r['id']}")
for r in S["nodes"]["rows"]:
    if r["drops"] not in ids["items"]: bad.append(f"BROKEN REF nodes.{r['id']}.drops")
    if r["requiresTool"] not in ids["items"]: bad.append(f"BROKEN REF nodes.{r['id']}.requiresTool")
for r in S["recipes"]["rows"]:
    for i in r["inputs"]:
        if i["item"] not in ids["items"]: bad.append(f"BROKEN REF recipes.{r['id']}.inputs")
    if r["output"] not in ids["items"]: bad.append(f"BROKEN REF recipes.{r['id']}.output")
print("\n".join(bad) if bad else "CLEAN")
sys.exit(1 if bad else 0)
